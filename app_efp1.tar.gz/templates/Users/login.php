<?php
/**
 * @var \App\View\AppView $this
 */
?>

<div class="users form">
    <h1>Iniciar sesión</h1>

    <?= $this->Form->create(null) ?>
    <fieldset>
        <legend>Acceso</legend>
        <?= $this->Form->control('correo', ['label' => 'Correo', 'required' => true]) ?>
        <?= $this->Form->control('password', ['label' => 'Contraseña', 'type' => 'password', 'required' => true]) ?>
    </fieldset>
    <?= $this->Form->button('Ingresar') ?>
    <?= $this->Form->end() ?>
</div>

